import { HeroSection } from "@/components/hero-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesSection } from "@/components/services-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { HowItWorksSection } from "@/components/how-it-works-section"
import { QuoteFormSection } from "@/components/quote-form-section"
import { ServiceAreaSection } from "@/components/service-area-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <BenefitsSection />
      <ServicesSection />
      <TestimonialsSection />
      <HowItWorksSection />
      <QuoteFormSection />
      <ServiceAreaSection />
      <Footer />
    </main>
  )
}
