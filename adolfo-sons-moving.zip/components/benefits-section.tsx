import { Card } from "@/components/ui/card"
import { Award, Users, Shield, Clock, DollarSign, Star } from "lucide-react"

const benefits = [
  {
    icon: Award,
    title: "20+ Years of Experience",
    description: "Trusted movers serving Antelope Valley since 1994",
  },
  {
    icon: Users,
    title: "Family-Owned & Operated",
    description: "Local, family-run business committed to personal service",
  },
  {
    icon: Shield,
    title: "Licensed & Insured",
    description: "Fully licensed and insured for your peace of mind",
  },
  {
    icon: Clock,
    title: "Same-Day Availability",
    description: "Local moves available same-day, 7 days a week",
  },
  {
    icon: DollarSign,
    title: "Clear, Honest Quotes",
    description: "No hidden fees — clear communication you can trust",
  },
  {
    icon: Star,
    title: "Top-Rated in Antelope Valley",
    description: "5-star reviews from families and businesses in your community",
  },
]

export function BenefitsSection() {
  return (
    <section className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">
            Why Families Trust <span className="text-primary">Adolfo & Sons Moving</span> in Antelope Valley
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Decades of reliable service, personal care, and peace of mind.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <Card
              key={index}
              className="p-8 text-center hover:shadow-lg transition-shadow border-2 hover:border-primary/20"
            >
              <div className="w-16 h-16 mx-auto mb-6 bg-primary/10 rounded-full flex items-center justify-center">
                <benefit.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-foreground">{benefit.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
