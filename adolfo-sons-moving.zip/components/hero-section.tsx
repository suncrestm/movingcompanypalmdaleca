import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/5">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/professional-movers-carrying-boxes-and-furniture.jpg"
          alt="Professional movers in action"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/10" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold text-balance mb-6 text-foreground">
            Moving in Palmdale or Anywhere in <span className="text-primary">Antelope Valley?</span>
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto leading-relaxed">
            Let Adolfo & Sons Moving & Trucking take the stress out of your next move — trusted by families and
            businesses since 1994.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button size="lg" className="text-lg px-8 py-6 bg-accent hover:bg-accent/90 text-accent-foreground">
              Get a Free Estimate
            </Button>
            <a
              href="tel:6616746450"
              className="flex items-center gap-2 text-lg font-semibold text-primary hover:text-primary/80 transition-colors"
            >
              <Phone className="w-5 h-5" />
              <span>📞 (661) 674-6450</span>
            </a>
          </div>

          <div className="text-sm text-muted-foreground">Available 7 days a week · Same-day service available</div>
        </div>
      </div>
    </section>
  )
}
