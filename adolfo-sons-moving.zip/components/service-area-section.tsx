import { Card } from "@/components/ui/card"
import { MapPin } from "lucide-react"

const serviceAreas = [
  {
    title: "Palmdale",
    description: "Our home base - serving all neighborhoods with same-day availability",
  },
  {
    title: "Lancaster",
    description: "Complete moving services throughout Lancaster and surrounding areas",
  },
  {
    title: "Quartz Hill",
    description: "Local expertise for all Quartz Hill residential and commercial moves",
  },
  {
    title: "Rosamond",
    description: "Reliable moving services for Rosamond families and businesses",
  },
  {
    title: "Littlerock",
    description: "Local moving services for Littlerock residents and businesses",
  },
  {
    title: "Nationwide",
    description: "Long-distance and interstate moving services across the United States",
  },
]

export function ServiceAreaSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">
            Our <span className="text-primary">Service Areas</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Proudly serving Antelope Valley and beyond with professional moving services
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {serviceAreas.map((area, index) => (
            <Card
              key={index}
              className="p-6 text-center hover:shadow-lg transition-shadow border-2 hover:border-accent/20"
            >
              <div className="w-12 h-12 mx-auto mb-4 bg-accent/10 rounded-full flex items-center justify-center">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">{area.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{area.description}</p>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-lg text-muted-foreground mb-4">
            Don't see your area listed? Give us a call - we may still be able to help!
          </p>
          <a href="tel:6616746450" className="text-2xl font-bold text-primary hover:text-primary/80 transition-colors">
            (661) 674-6450
          </a>
        </div>
      </div>
    </section>
  )
}
