import { Card } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Maria Rodriguez",
    location: "Palmdale, CA",
    rating: 5,
    text: "Adolfo and his team moved our entire 4-bedroom house in one day. They were professional, careful with our furniture, and the price was exactly what they quoted. Highly recommend!",
  },
  {
    name: "James Thompson",
    location: "Lancaster, CA",
    rating: 5,
    text: "Best moving experience ever! They handled our piano and antique furniture with such care. The team was punctual, friendly, and made our stressful move so much easier.",
  },
  {
    name: "Sarah Chen",
    location: "Quartz Hill, CA",
    rating: 5,
    text: "Used Adolfo & Sons for our office relocation. They worked around our schedule and had us up and running in our new location the next day. Exceptional service!",
  },
  {
    name: "Robert Martinez",
    location: "Rosamond, CA",
    rating: 5,
    text: "Called them for a last-minute move and they came the same day! Professional, efficient, and reasonably priced. This family business really cares about their customers.",
  },
  {
    name: "Lisa Johnson",
    location: "Palmdale, CA",
    rating: 5,
    text: "Moved from California to Arizona with Adolfo & Sons. They handled everything perfectly - packing, loading, and delivery. Nothing was damaged and they were so professional throughout.",
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">
            What Our <span className="text-primary">Customers Say</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Don't just take our word for it - hear from families and businesses we've helped move
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-muted-foreground mb-6 leading-relaxed italic">"{testimonial.text}"</p>
              <div>
                <div className="font-semibold text-foreground">{testimonial.name}</div>
                <div className="text-sm text-muted-foreground">{testimonial.location}</div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
