import { Card } from "@/components/ui/card"
import { FileText, Calendar, Truck } from "lucide-react"

const steps = [
  {
    icon: FileText,
    step: "1",
    title: "Request Your Free Quote",
    description:
      "Contact us by phone or fill out our form. We'll provide a detailed, no-obligation estimate for your move.",
  },
  {
    icon: Calendar,
    step: "2",
    title: "Schedule Your Move",
    description:
      "Choose a date and time that works for you. We offer flexible scheduling including weekends and same-day service.",
  },
  {
    icon: Truck,
    step: "3",
    title: "Relax While We Do the Heavy Lifting",
    description:
      "Our experienced team handles everything from packing to delivery, ensuring your belongings arrive safely at your new location.",
  },
]

export function HowItWorksSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">
            How It <span className="text-accent">Works</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Getting started with your move is simple and stress-free
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <Card
              key={index}
              className="p-8 text-center relative hover:shadow-lg transition-shadow border-2 hover:border-primary/20"
            >
              <div className="w-20 h-20 mx-auto mb-6 bg-primary rounded-full flex items-center justify-center">
                <step.icon className="w-10 h-10 text-primary-foreground" />
              </div>
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-accent rounded-full flex items-center justify-center text-accent-foreground font-bold text-lg">
                {step.step}
              </div>
              <h3 className="text-2xl font-bold mb-4 text-foreground">{step.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{step.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
