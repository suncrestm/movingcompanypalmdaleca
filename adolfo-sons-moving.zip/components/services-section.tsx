import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Home, Truck, Package, Building, Archive } from "lucide-react"

const services = [
  {
    icon: Home,
    title: "Local Moves",
    description:
      "Expert moving services throughout Palmdale, Lancaster, Quartz Hill, Rosamond, and all of Antelope Valley",
    features: ["Same-day availability", "Careful handling", "Local expertise"],
  },
  {
    icon: Truck,
    title: "Long Distance Moves",
    description: "State-to-state and cross-country moving services with full tracking and insurance coverage",
    features: ["Interstate licensed", "Real-time tracking", "Full insurance"],
  },
  {
    icon: Package,
    title: "Packing & Unpacking",
    description: "Professional packing services using high-quality materials to protect your belongings",
    features: ["Quality materials", "Expert technique", "Time-saving"],
  },
  {
    icon: Building,
    title: "Residential & Commercial",
    description: "Complete moving solutions for homes, offices, and businesses of all sizes",
    features: ["Flexible scheduling", "Specialized equipment", "Minimal downtime"],
  },
  {
    icon: Archive,
    title: "Storage Solutions",
    description: "Secure, climate-controlled storage options for short-term and long-term needs",
    features: ["Climate controlled", "Secure facility", "Flexible terms"],
  },
]

export function ServicesSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">
            Our <span className="text-accent">Moving Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Comprehensive moving solutions tailored to your specific needs
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {services.map((service, index) => (
            <Card key={index} className="p-8 hover:shadow-lg transition-shadow border-2 hover:border-accent/20">
              <div className="flex items-start gap-6">
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <service.icon className="w-8 h-8 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-4 text-foreground">{service.title}</h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="w-2 h-2 bg-accent rounded-full" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg">
            Get Custom Quote for Your Move
          </Button>
        </div>
      </div>
    </section>
  )
}
