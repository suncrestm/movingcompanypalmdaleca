import { Phone, Mail, Clock, CreditCard } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold mb-6">Adolfo & Sons Moving</h3>
            <p className="text-primary-foreground/80 mb-4 leading-relaxed">
              Family-owned and operated moving company proudly serving Antelope Valley for over 30 years with trusted,
              professional service.
            </p>
            <div className="space-y-2 text-sm">
              <div>DOT #: 123456</div>
              <div>MC #: 789012</div>
              <div>CA PUC #: T-345678</div>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-xl font-semibold mb-6">Contact Us</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5" />
                <a href="tel:6616746450" className="hover:text-accent transition-colors">
                  (661) 674-6450
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5" />
                <span>info@adolfosonsmoving.com</span>
              </div>
            </div>
          </div>

          {/* Business Hours */}
          <div>
            <h4 className="text-xl font-semibold mb-6">Business Hours</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>Every Day: 6:00 AM – 10:00 PM</span>
              </div>
            </div>
          </div>

          {/* Payment & Services */}
          <div>
            <h4 className="text-xl font-semibold mb-6">We Accept</h4>
            <div className="flex items-center gap-2 mb-6">
              <CreditCard className="w-5 h-5" />
              <span className="text-sm">Cash, Check, All Major Credit Cards</span>
            </div>

            <h5 className="font-semibold mb-3">Quick Links</h5>
            <div className="space-y-2 text-sm">
              <div>
                <a href="#services" className="hover:text-accent transition-colors">
                  Our Services
                </a>
              </div>
              <div>
                <a href="#quote" className="hover:text-accent transition-colors">
                  Get Quote
                </a>
              </div>
              <div>
                <a href="#reviews" className="hover:text-accent transition-colors">
                  Reviews
                </a>
              </div>
              <div>
                <a href="#contact" className="hover:text-accent transition-colors">
                  Contact
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm text-primary-foreground/80">
          <p>
            &copy; 2025 Adolfo & Sons Moving. All rights reserved. | Licensed & Insured | Serving Antelope Valley with
            Pride
          </p>
        </div>
      </div>
    </footer>
  )
}
