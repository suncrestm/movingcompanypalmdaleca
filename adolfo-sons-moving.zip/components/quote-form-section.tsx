"use client"

import type React from "react"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"

export function QuoteFormSection() {
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget

    try {
      const response = await fetch(form.action, {
        method: form.method,
        body: new FormData(form),
        headers: {
          Accept: "application/json",
        },
      })

      if (response.ok) {
        setIsSubmitted(true)
      }
    } catch (error) {
      console.error("Form submission error:", error)
    }
  }

  if (isSubmitted) {
    return (
      <section className="py-20 bg-primary/5">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Card className="p-8 md:p-12 text-center">
              <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">Thank You!</h2>
              <p className="text-xl text-muted-foreground">
                We'll get back to you within 2 hours during business hours.
              </p>
            </Card>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-balance mb-6">
              Get Your <span className="text-accent">Free Quote</span>
            </h2>
            <p className="text-xl text-muted-foreground text-pretty">
              Fill out the form below and we'll get back to you within 2 hours with a detailed estimate
            </p>
          </div>

          <Card className="p-8 md:p-12">
            <form method="POST" action="https://formspree.io/f/xpwyqapg" onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input id="name" name="name" placeholder="Enter your full name" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input id="email" name="email" type="email" placeholder="Enter your email" required />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input id="phone" name="phone" type="text" placeholder="(661) 555-0123" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="move-type">Move Type *</Label>
                  <Select name="move-type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select move type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Local">Local</SelectItem>
                      <SelectItem value="Long Distance">Long Distance</SelectItem>
                      <SelectItem value="Commercial">Commercial</SelectItem>
                      <SelectItem value="Packing Only">Packing Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="details">Tell us about your move</Label>
                <Textarea
                  id="details"
                  name="details"
                  placeholder="Please provide details about your move: number of rooms, special items, preferred dates, etc."
                  rows={4}
                />
              </div>

              <div className="text-center pt-4">
                <Button
                  type="submit"
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground px-12 py-6 text-lg"
                >
                  Get My Free Quote
                </Button>
                <p className="text-sm text-muted-foreground mt-4">We'll respond within 2 hours during business hours</p>
              </div>
            </form>
          </Card>
        </div>
      </div>
    </section>
  )
}
